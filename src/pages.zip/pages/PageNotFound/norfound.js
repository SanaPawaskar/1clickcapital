import React from "react"
import './style.css'

export default function PagenotFound () {

    return (
      <div className="main-not-found card">
      <h1>Page Not Found </h1>
      <h2>Post you are Looking for is deleted!!!!!!!</h2>
      </div>
    )
}